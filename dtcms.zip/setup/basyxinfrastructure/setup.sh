#!/bin/bash

cd "$(dirname "$0")"

# Load Environment Variables
source "../.env"
export MQTT_USERNAME=$MQTT_USERNAME
export MQTT_PASSWORD=$MQTT_PASSWORD

# Start Docker-Compose
docker-compose up -d --build 