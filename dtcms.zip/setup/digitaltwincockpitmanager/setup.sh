#!/bin/bash

cd "$(dirname "$0")"

# Load Environment Variables
source "../.env"

# Build Docker Image
docker build -t dtcm \
        --build-arg KEYSTORE_PASSWORD="$KEYSTORE_PASSWORD" \
        -f ./Dockerfile ../../.

# Run Docker Container
docker run -d --env-file ../.env \
        -p 7070:7070 \
        -p 8443:8443 \
        --restart=unless-stopped \
        --name digitaltwincockpitmanager \
        dtcm
