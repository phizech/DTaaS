#!/bin/bash

cd "$(dirname "$0")"

docker run -d \
  --env-file ../.env \
  --name mongodb \
  -p 27017:27017 \
  -v db:/data/db \
  mongo:latest